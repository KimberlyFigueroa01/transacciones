package uptc.banco.transacciones.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.IntByReference;

/**
 * Mantiene el saldo de la cuenta en memoria y delega el cálculo
 * del retiro al programa COBOL RETIRAR-DINERO (vía JNA).
 */
@Service
public class CuentaService {

    public static final double SALDO_INICIAL = 1000.00;

    /** Un movimiento registrado en el historial. */
    public record Movimiento(LocalDateTime fecha, double monto, boolean exitoso,
                             double saldoResultante, String mensaje) {}

    private double saldo = SALDO_INICIAL;
    private final List<Movimiento> historial = new ArrayList<>();

    public synchronized double getSaldo() {
        return saldo;
    }

    public synchronized List<Movimiento> getHistorial() {
        return Collections.unmodifiableList(new ArrayList<>(historial));
    }

    /**
     * Ejecuta un retiro. El monto se valida en Java porque el COBOL
     * no controla montos negativos ni cero.
     */
    public synchronized Movimiento retirar(double monto) {
        if (monto <= 0) {
            throw new IllegalArgumentException("El monto debe ser mayor que cero");
        }

        DoubleByReference refSaldo = new DoubleByReference(saldo);
        DoubleByReference refMonto = new DoubleByReference(monto);
        DoubleByReference refNuevoSaldo = new DoubleByReference(0.0);
        IntByReference refEstado = new IntByReference(0);

        Transaccion.INSTANCE.retirar_dinero(refSaldo, refMonto, refNuevoSaldo, refEstado);

        boolean exitoso = refEstado.getValue() == 0;
        if (exitoso) {
            saldo = refNuevoSaldo.getValue();
        }
        String mensaje = exitoso ? "Retiro exitoso" : "Rechazado: fondos insuficientes";

        Movimiento mov = new Movimiento(LocalDateTime.now(), monto, exitoso, saldo, mensaje);
        historial.add(0, mov);
        return mov;
    }

    /** Vuelve al saldo inicial (útil para repetir pruebas). */
    public synchronized void reiniciar() {
        saldo = SALDO_INICIAL;
        historial.clear();
    }
}
